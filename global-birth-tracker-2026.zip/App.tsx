
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { WorldMap } from './components/WorldMap';
import { BirthCounter } from './components/BirthCounter';
import { RecentBirths } from './components/RecentBirths';
import { BIRTHS_PER_SECOND, POP_COUNTRIES } from './constants';
import { BirthEvent } from './types';

const App: React.FC = () => {
  const [totalCount, setTotalCount] = useState(0);
  const [flashes, setFlashes] = useState<Map<string, number>>(new Map());
  const [recentEvents, setRecentEvents] = useState<BirthEvent[]>([]);
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }));
  const geoDataRef = useRef<any>(null);
  const eventIdRef = useRef(0);

  useEffect(() => {
    // Initial calculation
    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const secondsSinceMidnight = (now.getTime() - startOfDay.getTime()) / 1000;
    let currentTotal = Math.floor(secondsSinceMidnight * BIRTHS_PER_SECOND);
    setTotalCount(currentTotal);

    // Clock update
    const clockInterval = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }));
    }, 1000);

    // Fetch GeoData
    fetch('https://raw.githubusercontent.com/holtzy/D3-graph-gallery/master/DATA/world.geojson')
      .then(r => r.json())
      .then(data => { geoDataRef.current = data; });

    const spawnBirth = () => {
      const delay = (1000 / BIRTHS_PER_SECOND) * (0.7 + Math.random() * 0.6);
      setTimeout(() => {
        currentTotal++;
        setTotalCount(currentTotal);

        if (geoDataRef.current) {
          const countries = geoDataRef.current.features;
          const isHighPop = Math.random() > 0.4;
          let target = isHighPop 
            ? countries.find((f: any) => POP_COUNTRIES.includes(f.id || f.properties.ISO_A3))
            : countries[Math.floor(Math.random() * countries.length)];
          
          if (!target) target = countries[0];
          const countryId = target.id || target.properties.name || target.properties.ISO_A3;
          const countryName = target.properties.name || "Unknown Region";

          // Add to flashes
          setFlashes(prev => {
            const next = new Map(prev);
            next.set(countryId, Date.now());
            next.forEach((val, key) => {
              if (Date.now() - (val as number) > 5000) next.delete(key);
            });
            return next;
          });

          // Add to recent events
          setRecentEvents(prev => {
            const newEvent: BirthEvent = {
              id: eventIdRef.current++,
              country: countryName,
              time: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
            };
            return [newEvent, ...prev].slice(0, 5);
          });
        }
        spawnBirth();
      }, delay);
    };

    spawnBirth();
    return () => clearInterval(clockInterval);
  }, []);

  // Added useMemo to resolve the undefined name error
  const progressPercent = useMemo(() => {
    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const endOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1).getTime();
    return Math.min(100, Math.floor(((now.getTime() - startOfDay) / (endOfDay - startOfDay)) * 100));
  }, [currentTime]);

  return (
    <div className="relative w-full h-full bg-[#05010a] overflow-hidden font-sans text-white">
      {/* Background Globe Component */}
      <WorldMap flashes={flashes} />
      
      {/* Dashboard UI */}
      <div className="relative z-10 flex flex-col justify-between w-full h-full p-10 md:p-16 pointer-events-none">
        
        {/* Header Section */}
        <div className="flex flex-col items-start max-w-lg">
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-sm md:text-lg font-black tracking-widest text-[#d946ef] uppercase">
              MOTHER & CHILD CARE — WOMEN'S HEALTH
            </h1>
          </div>
          <div className="w-64 h-[2px] bg-amber-500 mb-2" />
        </div>

        {/* Main Content Area: Stats and Sidebar */}
        <div className="flex flex-col md:flex-row items-end justify-between w-full mt-auto mb-auto gap-8">
          
          {/* Left Column: Counter & Progress */}
          <div className="flex flex-col items-start gap-12">
            <BirthCounter count={totalCount} />
            
            <div className="flex flex-col items-start w-64">
              <div className="flex justify-between w-full mb-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">DAILY PROGRESS</span>
                <span className="text-[10px] font-bold text-amber-500">{progressPercent}%</span>
              </div>
              <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-amber-500 transition-all duration-1000" 
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>

            <div className="px-5 py-2 border border-slate-700 bg-slate-900/40 backdrop-blur rounded-md flex items-center justify-center">
              <span className="text-xl font-mono tracking-tighter text-amber-500">{currentTime}</span>
            </div>
          </div>

          {/* Right Column: Recent Activity Sidebar */}
          <div className="pointer-events-auto">
             <RecentBirths events={recentEvents} />
          </div>
        </div>

        {/* Footer Section */}
        <div className="flex justify-between items-end text-[9px] font-bold tracking-[0.3em] text-slate-600 uppercase">
          <div className="flex flex-col gap-1">
            <span>REAL-TIME GLOBAL SURVEILLANCE ACTIVE</span>
            <span className="text-slate-800">ENCRYPTION: 256-BIT AES // NODE: PRIMARY_CORE_01</span>
          </div>
          <span>© PHILIPS HEALTHCARE DIGITAL TWIN</span>
        </div>
      </div>

      {/* Cinematic Vignette */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_left,_transparent_30%,_rgba(0,0,0,0.8)_100%)] pointer-events-none" />
    </div>
  );
};

export default App;
