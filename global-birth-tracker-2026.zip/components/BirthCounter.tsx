
import React from 'react';

interface Props {
  count: number;
}

export const BirthCounter: React.FC<Props> = ({ count }) => {
  // Format with dot separators as shown in the image
  const formatted = count.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");

  return (
    <div className="flex flex-col items-start text-left">
      <h2 className="text-[11px] font-bold tracking-[0.2em] uppercase text-amber-500 mb-1 opacity-90">
        GLOBAL BIRTH COUNT TODAY
      </h2>
      <h1 className="text-7xl md:text-8xl font-black tracking-tight text-amber-400 tabular-nums drop-shadow-[0_0_20px_rgba(251,191,36,0.3)]">
        {formatted}
      </h1>
    </div>
  );
};
