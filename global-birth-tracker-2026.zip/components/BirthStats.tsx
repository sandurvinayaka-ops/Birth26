import React from 'react';

export const BirthStats: React.FC = () => {
  return (
    <div className="flex flex-col gap-4 text-slate-400">
      <div className="flex flex-col">
        <span className="text-[10px] font-bold uppercase tracking-widest text-slate-600">Avg Rate</span>
        <span className="text-sm font-mono text-amber-500">4.35 / sec</span>
      </div>
      <div className="flex flex-col">
        <span className="text-[10px] font-bold uppercase tracking-widest text-slate-600">Daily Projection</span>
        <span className="text-sm font-mono text-amber-500">~385,000</span>
      </div>
    </div>
  );
};
