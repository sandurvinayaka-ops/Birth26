
import React from 'react';
import { BirthEvent } from '../types';

interface Props {
  events: BirthEvent[];
}

export const RecentBirths: React.FC<Props> = ({ events }) => {
  return (
    <div className="w-full md:w-64 p-6 bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl">
      <h3 className="text-[10px] font-bold uppercase tracking-widest text-slate-500 mb-4 border-b border-white/5 pb-2">
        Recent Activity
      </h3>
      <div className="flex flex-col gap-4">
        {events.map((event, idx) => (
          <div 
            key={`${event.id}-${idx}`} 
            className="flex flex-col transition-all duration-500 animate-in fade-in slide-in-from-left-2"
            style={{ opacity: 1 - idx * 0.15 }}
          >
            <span className="text-[10px] font-bold text-pink-500 uppercase tracking-tighter">New Entry</span>
            <span className="text-sm font-medium text-slate-200">{event.country}</span>
            <span className="text-[9px] text-slate-500 font-mono uppercase">{event.time}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
