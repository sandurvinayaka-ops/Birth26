import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { COLORS, ROTATION_SPEED, FLASH_DURATION } from '../constants';

interface Props {
  flashes: Map<string, number>;
}

export const WorldMap: React.FC<Props> = ({ flashes }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const geoDataRef = useRef<any>(null);
  const rotationRef = useRef(0);
  const starsRef = useRef<{x: number, y: number, size: number, opacity: number}[]>([]);
  const pacifiersRef = useRef<{x: number, y: number, vx: number, vy: number, scale: number, opacity: number}[]>([]);

  useEffect(() => {
    fetch('https://raw.githubusercontent.com/holtzy/D3-graph-gallery/master/DATA/world.geojson')
      .then(res => res.json())
      .then(data => {
        geoDataRef.current = data;
      });

    // Stars
    starsRef.current = Array.from({ length: 200 }, () => ({
      x: Math.random(),
      y: Math.random(),
      size: Math.random() * 1.5,
      opacity: Math.random()
    }));

    // Pacifiers
    pacifiersRef.current = Array.from({ length: 10 }, () => ({
      x: Math.random(),
      y: Math.random(),
      vx: (Math.random() - 0.5) * 0.0006,
      vy: (Math.random() - 0.5) * 0.0006,
      scale: 0.4 + Math.random() * 0.6,
      opacity: 0.1 + Math.random() * 0.3
    }));

    const handleResize = () => {
      if (canvasRef.current) {
        canvasRef.current.width = window.innerWidth;
        canvasRef.current.height = window.innerHeight;
      }
    };
    window.addEventListener('resize', handleResize);
    handleResize();

    const render = () => {
      const canvas = canvasRef.current;
      if (!canvas) {
        requestAnimationFrame(render);
        return;
      }
      const ctx = canvas.getContext('2d');
      if (!ctx || !geoDataRef.current) {
        requestAnimationFrame(render);
        return;
      }

      const { width, height } = canvas;
      ctx.clearRect(0, 0, width, height);

      // Stars
      starsRef.current.forEach(star => {
        ctx.fillStyle = `rgba(255, 255, 255, ${star.opacity})`;
        ctx.beginPath();
        ctx.arc(star.x * width, star.y * height, star.size, 0, Math.PI * 2);
        ctx.fill();
      });

      // Pacifiers
      pacifiersRef.current.forEach(p => {
        p.x = (p.x + p.vx + 1) % 1;
        p.y = (p.y + p.vy + 1) % 1;
        
        ctx.save();
        ctx.translate(p.x * width, p.y * height);
        ctx.scale(p.scale, p.scale);
        ctx.beginPath();
        // Classic pacifier path
        const path = new Path2D("M10 5a2 2 0 1 1-4 0 2 2 0 0 1 4 0zM8 8a3.99 3.99 0 0 0-3.858 5H3.5a.5.5 0 0 0 0 1h.642a4 4 0 1 0 7.716 0H12.5a.5.5 0 0 0 0-1h-.642A3.99 3.99 0 0 0 8 8z");
        ctx.fillStyle = `rgba(147, 197, 253, ${p.opacity})`;
        ctx.shadowBlur = 10;
        ctx.shadowColor = 'rgba(147, 197, 253, 0.5)';
        ctx.fill(path);
        ctx.restore();
      });

      const projection = d3.geoOrthographic()
        .scale(Math.min(width, height) * 0.45)
        .translate([width * 0.75, height / 2])
        .rotate([rotationRef.current, -15]);

      const path = d3.geoPath(projection, ctx);

      // Globe Ocean
      ctx.beginPath();
      ctx.arc(width * 0.75, height / 2, projection.scale(), 0, 2 * Math.PI);
      ctx.fillStyle = '#110224';
      ctx.fill();

      // Atmospheric Glow
      const grad = ctx.createRadialGradient(width * 0.75, height / 2, projection.scale() * 0.9, width * 0.75, height / 2, projection.scale() * 1.2);
      grad.addColorStop(0, 'rgba(124, 58, 237, 0)');
      grad.addColorStop(1, 'rgba(124, 58, 237, 0.25)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      // Countries
      geoDataRef.current.features.forEach((feature: any) => {
        const id = feature.id || feature.properties.name || feature.properties.ISO_A3;
        const flashTime = flashes.get(id);
        const isFlashing = flashTime && (Date.now() - flashTime < FLASH_DURATION);

        ctx.beginPath();
        path(feature);
        
        if (isFlashing) {
          const t = 1 - ((Date.now() - flashTime!) / FLASH_DURATION);
          ctx.fillStyle = d3.interpolateRgb(COLORS.LAND, COLORS.FLASH)(t);
          ctx.shadowBlur = 35 * t;
          ctx.shadowColor = COLORS.FLASH;
        } else {
          ctx.fillStyle = COLORS.LAND;
          ctx.shadowBlur = 0;
        }
        
        ctx.fill();
        ctx.strokeStyle = isFlashing ? COLORS.FLASH : COLORS.LAND_BORDER;
        ctx.lineWidth = isFlashing ? 1.5 : 0.4;
        ctx.stroke();
      });

      rotationRef.current += ROTATION_SPEED;
      requestAnimationFrame(render);
    };

    render();
    return () => window.removeEventListener('resize', handleResize);
  }, [flashes]);

  return <canvas ref={canvasRef} className="absolute inset-0 z-0" />;
};
