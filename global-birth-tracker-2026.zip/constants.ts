
export const BIRTHS_PER_SECOND = 4.35;
export const FLASH_DURATION = 3000;
export const ROTATION_SPEED = 0.008;

export const COLORS = {
  BG: '#020005',
  LAND: '#5b21b6', // Deep purple
  LAND_BORDER: '#7c3aed', // Lighter purple border
  FLASH: '#fbbf24', // Amber/Yellow highlight
  TEXT_HEADING: '#d946ef', // Fuchsia/Purple heading
  TEXT_PRIMARY: '#fbbf24', // Amber text for counter
  ACCENT: '#fbbf24',
  GLOW: 'rgba(251, 191, 36, 0.4)',
};

export const POP_COUNTRIES = [
  'IND', 'CHN', 'NGA', 'PAK', 'IDN', 'BRA', 'ETH', 'BGD', 'USA', 'COD',
  'MEX', 'PHL', 'EGY', 'VNM', 'TUR', 'IRN', 'DEU', 'THA', 'GBR', 'FRA'
];
