
export interface BirthEvent {
  id: number;
  country: string;
  time: string;
}

export interface FlashState {
  id: string;
  timestamp: number;
}
